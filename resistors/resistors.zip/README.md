Just a calculator on the Carbon Coded and Metal Film Resistors
